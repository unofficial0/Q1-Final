﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketException
{
    
        [Serializable]
        public class T_Exception : Exception
        {
            public T_Exception() { }
            public T_Exception(string message) : base(message) { }
            public T_Exception(string message, Exception inner) : base(message, inner) { }
            protected T_Exception(
              System.Runtime.Serialization.SerializationInfo info,
              System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
        }

}

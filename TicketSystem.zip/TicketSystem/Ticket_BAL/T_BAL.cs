﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Ticket_DAL;
using Ticket_Entity;
using TicketException;

namespace Ticket_BAL
{
    public class T_BAL
    {
        public static int firstDigit(int n)
        {
            while (n >= 10)
            {
                n = n / 10;
            }
            return n;
        }
        private static bool ValidateCustomer(T_Entity c)

        {

            StringBuilder sb = new StringBuilder();

            bool validCus = true;

            if (firstDigit(c.PNRNumber)!=8)

            {

                validCus = false;

                sb.Append(Environment.NewLine + "PNR Must Start With 8");

            }

            if ((c.Source ==string.Empty) && (c.Destination==string.Empty))

            {

                validCus = false;

                sb.Append(Environment.NewLine + "Enter  Source/Destination");

            }

            if (c.BookingDate == DateTime.Now)

            {

                validCus = false;

                sb.Append(Environment.NewLine + "Booking Date Must be Today");

            }

            if ((c.DateOfJourney!= DateTime.Now) &&(c.DateOfJourney< DateTime.Now))

            {

                validCus = false;

                sb.Append(Environment.NewLine + "Date Of Journey Must today or Tomorrow");

            }

            if(c.Type==string.Empty)
            {
                c.Type = "SLEEPER";
            }
            if((c.Type!="SLEEPER") & (c.Type!="3AC") & (c.Type != "2AC") & (c.Type != "1AC"))
        
            {
                validCus = false;
                sb.Append(Environment.NewLine + "Type must be SLEEPER or 3AC or 2AC or 1AC");
            }
            if (validCus == false)

                throw new T_Exception(sb.ToString());

            return validCus;

        }


        public static bool AddCustomerBAL(T_Entity c)

        {

            bool CusAdded = false;

            try

            {

                if (ValidateCustomer(c))

                {

                    T_DAL dal = new T_DAL();

                    CusAdded = dal.AddCustomerDAL(c);

                }

            }

            catch (T_Exception e)

            {

                throw;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return CusAdded;

        }


        public static T_Entity SearchCustomerBAL(int searchPNR)

        {

            T_Entity searchCust = null;

            try

            {

                T_DAL dal = new T_DAL();
                searchCust = dal.SearchCustomerDAL(searchPNR);

            }

            catch (T_Exception ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return searchCust;

        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ticket_Entity;
using TicketException;

namespace Ticket_DAL
{
    public class T_DAL
    {
        static List<T_Entity> CList = new List<T_Entity>();

        public bool AddCustomerDAL(T_Entity c)

        {

            bool CAdded = false;

            try

            {

                CList.Add(c);

                CAdded = true;



            }

            catch (Exception ex)

            {

                throw new T_Exception(ex.Message);

            }

            return CAdded;

        }




        public T_Entity SearchCustomerDAL(int searchPNR)

        {

            T_Entity searchC = null;

            try

            {



                for (int i = 0; i < CList.Count; i++)

                {

                    T_Entity c = CList[i];

                    if (c.PNRNumber == searchPNR)

                    {

                        searchC = CList[i];

                        break;

                    }

                }

            }

            catch (Exception ex)

            {

                throw new T_Exception(ex.Message);

            }

            return searchC;

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ticket_Entity
{
    public class T_Entity
    {
        public int PNRNumber { get; set; }
        public string  Source { get; set; }
        public string Destination { get; set; }
        public DateTime DateOfJourney { get; set; }
        public DateTime BookingDate { get; set; }
        public string Type { get; set; }
        public int NoOfTickets { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ticket_BAL;
using Ticket_Entity;
using TicketException;

namespace Ticket_PL
{
    class T_PL
    {
        static void Main(string[] args)
        {

            PrintMenu();
            Console.ReadKey();
        }

        private static void PrintMenu() //Print Menu

        {

            string choice1;

            do

            {

                Console.WriteLine("\n***********Ticket Booking Details of Customer ***********");

                Console.WriteLine("1. Add Booked Ticket Details");


                Console.WriteLine("2. Search Ticket Details");



                int choice = Int32.Parse(Console.ReadLine());

                switch (choice)

                {

                    case 1:

                        AddCustomer();

                        break;

                    case 2:

                        SearchByPNR();

                        break;


                }

                Console.WriteLine("Do you want to contiue(y/n)?");

                choice1 = Console.ReadLine();

            } while ((choice1 == "y"));


        }

        private static void AddCustomer()
        { 

            try

            {

                T_Entity Cust = new T_Entity();





                Console.WriteLine("Enter PNR Number");
                Cust.PNRNumber = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Source:");
                Cust.Source = Console.ReadLine();

                Console.WriteLine("EnterDestination :");
                Cust.Destination = Console.ReadLine();

                Console.WriteLine("Enter Date Of Journey :");
                Cust.DateOfJourney =Convert.ToDateTime(Console.ReadLine());

                Console.WriteLine("Enter Booking Date :");
                Cust.BookingDate = Convert.ToDateTime(Console.ReadLine());

                Console.WriteLine("Enter Type :");
                Cust.Type = Console.ReadLine();

                Console.WriteLine("Enter Number Of Tickets :");
                Cust.NoOfTickets = Convert.ToInt32(Console.ReadLine());

               bool custAdded = T_BAL.AddCustomerBAL(Cust);

                if (custAdded)

                    Console.WriteLine("Ticket Booked");

                else

                    Console.WriteLine("Ticket not Booked");

            }

            catch (T_Exception ex)

            {

                Console.WriteLine(ex.Message);

            }

        }


        private static void SearchByPNR() // Search Customer Details by PNR

        {

            try

            {

                int searchCustID;

                Console.WriteLine("Enter PNR to Search:");

                searchCustID = Convert.ToInt32(Console.ReadLine());

                T_Entity searchcust = T_BAL.SearchCustomerBAL(searchCustID);

                if (searchcust != null)

                {           
                    Console.WriteLine("PNR Number:"+ searchcust.PNRNumber);
                    Console.WriteLine("Source:" + searchcust.Source);
                    Console.WriteLine("Destination:" + searchcust.Destination);
                    Console.WriteLine("DateOfJourney:" + searchcust.DateOfJourney);
                    Console.WriteLine("BookingDate:" + searchcust.BookingDate);
                    Console.WriteLine("Type:" + searchcust.Type);
                    Console.WriteLine("NoOfTickets:" + searchcust.NoOfTickets);
                }

                else

                {

                    Console.WriteLine("No Customer Details Available");

                    Console.ReadLine();

                }

            }

            catch (T_Exception ex)

            {

                Console.WriteLine(ex.Message);

            }

        }


    }
}
